<div class="top_header">
    <span class="layui-breadcrumb" lay-separator="|">
        <a lay-href="Member/Member_list.php">신규가입:<font class="money_red">1명</font></a>
        <!-- NewMemberShip -->
        <a lay-href="Money/Money_inslist.php">충전:<font class="money_red">1명</font></a>
        <!-- Charge -->
        <a lay-href="Money/Money_outlist.php">환전:<font class="money_red">1명</font></a>
        <!-- Currency Exchange -->
        <a href="javascript:;">문의:<font class="money_defalut">0</font></a>
        <!-- contact-->
        <a href="javascript:;">온라인:<font class="money_defalut">1명</font></a>
        <!-- online-->
        <a href="javascript:;">보유머니:<font class="money_defalut">100,100,000</font></a>
        <!-- money on hand-->
        <a href="javascript:;">보유포인트:<font class="money_defalut">100,100,000</font></a>
        <!-- posssesion-->
        <a href="javascript:;">충전:<font class="money_defalut">100,100,000</font></a>
        <!-- Recharge-->
        <a href="javascript:;">환전:<font class="money_defalut">100,100,000</font></a>
        <!-- currency exchange-->
        <a href="javascript:;">스포츠배팅:<font class="money_defalut">100,100,000</font></a>
        <!-- sports betting-->
        <a href="javascript:;">스포츠대기:<font class="money_defalut">100,100,000</font></a>
        <!-- Stand by sport-->
        <a href="javascript:;">스포츠당첨:<font class="money_defalut">100,100,000</font></a>
        <!-- sports win-->
    </span>
</div>